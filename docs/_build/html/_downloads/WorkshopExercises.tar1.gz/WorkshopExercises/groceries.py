foods = {"apple": 1.50,
         "banana": 2.00,
         "milk": 4.00,
         "bread": 3.50}

num_bananas = 3
num_apples = 1
num_milk = 1
num_bread = 2

total = 0
total = total + foods.get("banana") * num_bananas
total = total + foods.get("apple") * num_apples
total = total + foods.get("milk") * num_milk
total = total + foods.get("bread") * num_bread

# This print statement uses special format characters:
# a) %f by itself means "I'm a placeholder for a float.
# b) 0.2 means "print 2 places after the decimal.
# c) %0.2f means print a float, displaying 2 places after the decimal.
print "Your total is: $%0.2f" % (total,)
