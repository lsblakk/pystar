a = 0
b = 1

while b < 1000:
    # Without a comma, print will insert a newline.
    print b,
    old_a = a
    a = b
    b = old_a + b
