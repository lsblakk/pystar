class Animal(object):
    def __init__(self, name):
        self.name = name

    def sayName(self):
        print "My name is", self.name

class Dog(Animal):
    def makeNoise(self):
        print "Woof woof"

    def describeCoat(self):
        raise NotImplementedError()

class Dalmation(Dog):
    def describeCoat(self):
        print "I have spots!"

class GoldenRetriever(Dog):
    pass

dalmation = Dalmation("Dot")
dalmation.sayName()
dalmation.makeNoise()
dalmation.describeCoat()

golden = GoldenRetriever("Lassy")
golden.sayName()
golden.makeNoise()
golden.describeCoat()
