while True:
    input = raw_input("Tell me something. Type 'exit' to quit > ")
    if input == "exit":
        print "Thanks for playing!"
        break
    else:
        print input
