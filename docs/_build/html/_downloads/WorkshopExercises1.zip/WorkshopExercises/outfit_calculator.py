tops = ["blue t-shirt", "black turtleneck", "white tank-top"]
bottoms = ["jeans", "slacks", "leggings"]
shoes = ["heels", "tennis shoes", "sandals"]

counter = 0
for top in tops:
    for bottom in bottoms:
        for shoe in shoes:
            counter = counter + 1
            # %s is the string formatting sequence for strings.
            print "%s, %s, %s" % (top, bottom, shoe)

# Inside a string, '\n' means a newline.
# %d is the string formatting sequence for integers.
print "\nYou have a total of %d outfit choices" % (counter,)
