import sys

def encrypt(message, shift):
    shifted_message = ""
    for character in message:
        # Given a character, ord() returns an integer.
        # chr() is the opposite of ord(). Given an integer, it converts that
        # integer into the appropriate character.
        shifted_character = chr(ord(character) + shift)
        shifted_message = shifted_message + shifted_character

    # shifted_message now contains your original message with each character
    # incremented by `shift`.
    return shifted_message

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print "Please supply a filename and a shift."
        exit(1)

    message_file = sys.argv[1]

    try:
        message = file(message_file).read()
    except IOError:
        print "Couldn't find file %s" % (message_file,)

    try:
        shift = int(sys.argv[2])
    except ValueError:
        print "Please enter an integer for the shift."
        exit(1)
    
    encrypted_message = encrypt(message, shift)
    print encrypted_message
    output_file = open("encryption_output.txt", "w")
    output_file.write(encrypted_message)
