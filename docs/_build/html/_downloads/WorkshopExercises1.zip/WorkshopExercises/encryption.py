def encrypt(message, shift):
    shifted_message = ""
    for character in message:
        # Given a character, ord() returns an integer.
        # chr() is the opposite of ord(). Given an integer, it converts that
        # integer into the appropriate character.
        shifted_character = chr(ord(character) + shift)
        shifted_message = shifted_message + shifted_character

    # shifted_message now contains your original message with each character
    # incremented by `shift`.
    return shifted_message
