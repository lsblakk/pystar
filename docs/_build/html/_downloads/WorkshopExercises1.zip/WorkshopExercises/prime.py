# This is an algorithm to calculate the prime numbers between 2 and
# 25. For each number n between 2 and 25: for all numbers x less than
# n, if x divides n evenly, ie there is no remainder, x must be a
# factor of n, and n isn't prime.

for n in range(2, 25):
    # We don't start with 1 because all numbers can be divided by one
    # and that doesn't tell us anything about if they're prime or not.
    x = 2
    while x < n:
        if n % x == 0:
            # There was no remainder, so n isn't prime
            print n, 'equals', x, '*', n/x
            break
        x = x + 1
    # n isn't divisible by any numbers between 2 and n-1, so n is prime.
    if x == n:
        print n, 'is a prime number'
