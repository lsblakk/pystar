names = ["Alice", "Betty", "Cory", "Dora", "Eve"]
vowels = ["a", "e", "i", "o", "u"]

# Use append() to add an element to a list
names.append("Fiona")

# Use extend() to add one list to another
more_names = ["Glenda", "Harry", "Isabel"]
names.extend(more_names)

for name in names:
    if name[0].lower() in vowels:
        print name, "starts with a vowel"
