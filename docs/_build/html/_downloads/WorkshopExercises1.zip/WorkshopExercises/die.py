import random

print random.randint(1, 6)
